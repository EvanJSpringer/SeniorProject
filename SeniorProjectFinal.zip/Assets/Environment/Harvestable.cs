using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Harvestable : Interaction
{
    public GameObject drop;
}
